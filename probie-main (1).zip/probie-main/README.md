# Welcome Probies! 🎓

Google Classroom Link: https://classroom.google.com/c/ODE4MTgyMjI0NzA3?cjc=qxcfvamm

OPENROUTER_API_KEY=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
